package com.cg.dao;

import java.util.List;

import com.cg.entity.hoteldetails;

public interface HotelRepository {
	
	//method to retrieve hoteldetails from database
	public abstract List<hoteldetails> loadAll();
}
