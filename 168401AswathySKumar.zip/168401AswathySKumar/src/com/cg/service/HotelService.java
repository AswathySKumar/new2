package com.cg.service;

import java.util.List;

import com.cg.entity.hoteldetails;

public interface HotelService {
	
	//method to retrieve hoteldetails from database
	public abstract List<hoteldetails> loadAll();
}
