package com.cg.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.HotelRepository;
import com.cg.entity.Users;

@Service
@Transactional
public class HotelServiceImpl implements HotelService{
	@Autowired
	private HotelRepository hotelRepository;

	@Override
	public List<Users> loadAl() {
		// TODO Auto-generated method stub
		return hotelRepository.loadAl();
	}

	@Override
	public Users save(Users user) {
		
		return hotelRepository.save(user) ;
	}

	
	

}
