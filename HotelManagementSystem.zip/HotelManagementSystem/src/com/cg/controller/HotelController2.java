package com.cg.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Users;
import com.cg.service.HotelService;

@Controller
public class HotelController2 {
	
@Autowired
private HotelService hotelService;

@RequestMapping("/index")
public String welcome(){
	return "index";
}

@RequestMapping("/register")
public String getHomePage(Model model){
	model.addAttribute("UserList",hotelService.loadAl());

model.addAttribute("user",new Users());
return "booking1";
}


@RequestMapping(value="/save")
public String register(@ModelAttribute("user") Users user,Model model){
	user=hotelService.save(user);
	model.addAttribute("message","Registered successfully!");
	return "redirect:/register.html";
	
}
}
