package com.cg.service;



import java.util.List;

import com.cg.entity.Users;


public interface HotelService {



	List<Users> loadAl();

	public abstract Users save(Users user);
	
	
}
