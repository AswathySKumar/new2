package com.cg.dao;

import java.util.List;

import com.cg.entity.Users;




public interface HotelRepository {
	
	List<Users> loadAl();

	public abstract Users save(Users user);
}
