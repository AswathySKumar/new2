package com.cg.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.entity.Users;


@Repository
public class HotelRepositoryImpl implements HotelRepository{
	
@PersistenceContext
private EntityManager entityManager;

@Override
public List<Users> loadAl() {
	TypedQuery<Users>query=entityManager.createQuery("SELECT e FROM Users e",Users.class);
	return query.getResultList();
}

@Override
public Users save(Users user) {
	entityManager.persist(user);
	entityManager.flush();
	return user;
}

//method to retrieve hoteldetails from database

	}


