package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.hoteldetails;
@Repository
public class HotelRepositoryImpl implements HotelRepository{
	
@PersistenceContext
private EntityManager entityManager;

//method to retrieve hoteldetails from database
@Override
public List<hoteldetails> loadAll() {
TypedQuery<hoteldetails> query=entityManager.createQuery("SELECT h FROM hoteldetails h",hoteldetails.class);
return query.getResultList();
}
	}


