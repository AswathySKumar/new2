package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.hoteldetails;
import com.cg.service.HotelService;

@Controller
public class HotelController {
	
@Autowired
private HotelService hotelService;



//method to show the details of hotel in homepage
@RequestMapping(value="/index")
public String getHomePage(Model model){
model.addAttribute("hotelList",hotelService.loadAll());//hoteldetails are stored in hotelList
model.addAttribute("hotel",new hoteldetails());
return "index";
	                                  }

//method for showing the confirmation page to the user	
@RequestMapping(value="/success")
public String getHome(@RequestParam(value="hid") String name,Model model,hoteldetails hoteldetails)//hotelnames are stored in variable hid and given to variable name
{
model.addAttribute("msg",name);
return "BookingConfirmation";
}
	
}
