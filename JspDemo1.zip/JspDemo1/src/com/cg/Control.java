package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Control
 */
@WebServlet("/control.do")
public class Control extends HttpServlet {
	String title="";
	public Control() {
		System.out.println("in constructor");
		
	}
	@Override
	public void init() throws ServletException {
		title="my servlet application";
	}
/*protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException ,IOException {
		
		System.out.println("in service");
		String meth=arg0.getMethod();
		System.out.println(meth);
		if("GET".equals(meth)){
			doGet(arg0, arg1);
		}
		else{
			doPost(arg0, arg1);
		}
		
	}
public void destroy(){
	title=null;	
	System.out.println(title+" its in destroy");
}*/

	PrintWriter out=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
		out=resp.getWriter();
		out.println("<html><head>");
		out.println("<title>"+title+"</title></head>");
		System.out.println("<title>"+title+"</title></head>");
		out.println("<body>");
		if(9>89){
			out.println("<h1>hello</h1>");
		}
		else{
			out.println("<h1>welcome!!!</h1>");
		}
		out.println("</body>");
		
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
	}
}
